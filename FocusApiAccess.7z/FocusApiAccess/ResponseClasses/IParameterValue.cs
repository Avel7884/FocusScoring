namespace FocusApiAccess.ResponseClasses
{                    //TODO rearcitect
    public interface IParameterValue
    {
    }
}