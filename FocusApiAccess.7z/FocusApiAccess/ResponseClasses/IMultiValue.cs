using System.Collections.Generic;
using Newtonsoft.Json;

namespace FocusApiAccess.ResponseClasses
{/*
    [JsonArrayAttribute]
    public interface IMultiValue<T> : IList<T>, IParameterValue {}*/
}