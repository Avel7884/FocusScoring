namespace FocusApiAccess
{
    public class NzaUrlArg : QueryComponents
    {
        public NzaUrlArg(string query)
        {}

        public NzaUrlArg()
        {}

        public override string[] Keys { get; } = {"nza"};
    }
}