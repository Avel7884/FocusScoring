namespace FocusApiAccess
{
    public interface IPostArguments : IQueryComponents
    {
        string Data { get; }
    }
}