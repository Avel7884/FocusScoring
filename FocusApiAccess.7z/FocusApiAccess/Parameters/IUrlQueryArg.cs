namespace FocusApiAccess
{
    internal interface IUrlQueryArg
    {
        string ToQueryArg();
    }
}